window.AD_CONFIG = {
  size: { w: 160, h: 600 },
  clickUrl: "https://nbdeveloper.ch",
  copy: {
    headline: "Engineering\nDigital Systems",
    subline: "Built for performance at scale",
    cta: "Learn More"
  },
  motion: { loops: 2, loopDelay: 1.2 }
};
