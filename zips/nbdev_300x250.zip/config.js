window.AD_CONFIG = {
  size: { w: 300, h: 250 },
  clickUrl: "https://nbdeveloper.ch",
  copy: {
    headline: "Engineering Digital Systems",
    subline: "Built for performance at scale",
    cta: "Learn More"
  },
  motion: { loops: 2, loopDelay: 1.2 }
};
