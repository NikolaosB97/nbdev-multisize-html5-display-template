window.AD_CONFIG = {
  size: { w: 728, h: 90 },
  clickUrl: "https://nbdeveloper.ch",
  copy: {
    headline: "Engineering Digital Systems",
    subline: "Performance at scale",
    cta: "Learn More"
  },
  motion: { loops: 2, loopDelay: 1.2 }
};
